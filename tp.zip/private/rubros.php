<?php
$rubros = [
    "Ropa" => "Ropa",
    "Electrónica" => "Electrónica",
    "Joyería" => "Joyería",
    "Calzado" => "Calzado",
    "Librería" => "Librería",
    "Alimentos" => "Alimentos",
    "Bebidas" => "Bebidas",
    "Farmacia" => "Farmacia",
    "Deportes" => "Deportes",
    "Muebles" => "Muebles",
    "Hogar" => "Hogar",
    "Automóviles" => "Automóviles",
    "Belleza" => "Belleza",
    "Viajes" => "Viajes",
    "Otros" => "Otros"
];?>
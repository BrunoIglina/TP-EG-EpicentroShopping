<link rel="stylesheet" href="../css/footer.css">
<footer>
    <p>Epicentro Shopping - Todos los derechos reservados © 2024</p>
    <p>Contacto: <a href="mailto:admin@epicentroshopping.com" ><u>admin@epicentroshopping.com</u></a></p>
</footer>